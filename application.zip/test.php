<?php
session_start();

var_dump($_SESSION['isLogin']);
?>
//http://img.youtube.com/vi/<insert-youtube-video-id-here>/0.jpg