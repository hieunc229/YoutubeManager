<?php
namespace Application\Model;
class Category {
	public $id, $name, $des, $img;
}
?>