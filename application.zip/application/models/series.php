<?php
namespace Application\Model;
class Series {
	public $id, $name, $cat_id, $cat_name, $v;
}
?>