<?php
namespace Application\Model;
class Link {
	public $id, $v, $name, $des, $ser_id, $ser_name, $cat_id, $cat_name;
}
?>