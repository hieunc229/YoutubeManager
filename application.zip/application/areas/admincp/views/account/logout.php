<div class="alert alert-success" role="alert">
  <b>Logout successfull</b>
</div>