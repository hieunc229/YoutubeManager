<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title><?php echo $this->variables['title']; ?></title>
	<link href="/styles/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css">
	<link href="/styles/_layout.css" rel="stylesheet" type="text/css">
	<link rel="icon" href="/styles/mvicon.ico">
</head>
<body>
	<div class="panel panel-default">
			<nav class="navbar navbar-default nav-black-style">
			  <div class="container-fluid">
			    <!-- Brand and toggle get grouped for better mobile display -->
			    <div class="navbar-header">
			      
			    	<?php \Application\HTMLHelper::InsertImage(WEBSITE_URL.DS.'styles/mvicon.png','MVideo', 'inline-block margin-10', 30, 30); ?>
			    	<!-- <a class="navbar-brand inline-block"><?php echo $this->variables['title']; ?></a> -->
			    </div>
			    <!-- Collect the nav links, forms, and other content for toggling -->  
			    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
			    <?php if(\Application\HTMLHelper::IsLogin()) { ?>
			      <ul class="nav navbar-nav">
			        <li id="category"><a href="<?php echo WEBSITE_URL; ?>/admincp/category">Categories<span class="sr-only">(current)</span></a></li>
			        <li id="series"><a href="<?php echo WEBSITE_URL; ?>/admincp/series">Series</a></li>
			        <li id="link"><a href="<?php echo WEBSITE_URL; ?>/admincp/link">Links</a></li>
			      </ul>
			    <?php } ?>
			      <ul class="nav navbar-nav navbar-right">
			        <li id="home"><a href="<?php echo WEBSITE_URL; ?>/admincp/home">Cpanel</a></li>
			        <li><a href="<?php echo WEBSITE_URL; ?>">Home</a></li>
			        <?php if(\Application\HTMLHelper::IsLogin()) { ?>
			        <li><a href="<?php echo WEBSITE_URL; ?>/admincp/account/logout">Logout</a></li>
			        <?php } ?>
			      </ul>
			    </div><!-- /.navbar-collapse -->
			    
			  </div><!-- /.container-fluid -->
			</nav>
		    <div class="panel-body containter">

		<?php
			$this->include_view($this->body);
		?>
			</div>
	</div>
	<script type="text/javascript" src="/scripts/jquery.min.js"></script>
	<script type="text/javascript" src="/styles/bootstrap/js/bootstrap.min.js"></script>
	<script type="text/javascript" src="/scripts/mvscripts.js"></script>


</body>
</html>