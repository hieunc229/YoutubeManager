<?php
echo 	'<div class="embed-responsive embed-responsive-16by9">
  			<iframe class="embed-responsive-item" src="https://www.youtube.com/embed/'.$this->variables['video']->v.'"></iframe>
		</div>';
?>