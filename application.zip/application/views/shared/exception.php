<?php

	echo $this->variables['message'];
?>