<?php
	$registedArea = array(
			'cpanel');

	define('REGISTED_AREA', $registedArea);
?>